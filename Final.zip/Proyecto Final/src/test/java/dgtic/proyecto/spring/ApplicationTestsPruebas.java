package dgtic.proyecto.spring;

import dgtic.proyecto.repository.*;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

@SpringBootTest
class ApplicationTestsPruebas {

	static final String ALUMNO= "Brian Eduardo Guerrero";

	@Autowired
	CategoriaProductoRepository categoriaProductoRepository;
	@Autowired
	ProductoRepository productoRepository;
	@Autowired
	RolRepository rolRepository;
	@Autowired
	UsuarioRepository usuarioRepository;
	@Autowired
	DetalleVentaRepository detalleVentaRepository;
	@Autowired
	TicketVentaRepository ticketVentaRepository;
	@Autowired
	ClienteRepository clienteRepository;
	@Autowired
	TipoPagoRepository tipoPagoRepository;

	@Test
	@Transactional
	void buscarTodosProducto(){
		System.out.println("Buscar todos los Clientes  ");
		productoRepository.findAll().forEach(System.out::println);
	}
	@Test
	@Transactional
	void buscarTodosTickets(){
		System.out.println(ALUMNO);
		System.out.println("Buscar todos los Clientes  ");
		ticketVentaRepository.findAll().forEach(System.out::println);
	}
	@Test
	@Transactional
	void buscarTodosDetalleVenta(){
		System.out.println(ALUMNO);
		System.out.println("Buscar todos los Clientes  ");
		detalleVentaRepository.findAll().forEach(System.out::println);
	}
	@Test
	@Transactional
	void buscarTodosPorRol(){
		System.out.println(ALUMNO);
		System.out.println("Buscar todos los Clientes  ");
		rolRepository.findAll().forEach(System.out::println);
	}
	@Test
	@Transactional
	void buscarTodosPorUsuario(){
		System.out.println(ALUMNO);
		System.out.println("Buscar todos los Clientes  ");
		usuarioRepository.findAll().forEach(System.out::println);
	}

	@Test
	@Transactional
	void buscarTodosPorCategoria(){
		System.out.println(ALUMNO);
		System.out.println("Buscar todos los Clientes  ");
		categoriaProductoRepository.findAll().forEach(System.out::println);
	}
	@Test
	@Transactional
	void buscarTodosPorCliente(){
		System.out.println(ALUMNO);
		System.out.println("Buscar todos los Clientes  ");
		clienteRepository.findAll().forEach(System.out::println);
	}
	@Test
	@Transactional
	void buscarTodosPorTipoPago(){
		System.out.println(ALUMNO);
		System.out.println("Buscar todos los Clientes  ");
		tipoPagoRepository.findAll().forEach(System.out::println);
	}

}
