package dgtic.proyecto.controller.usuario;

import dgtic.proyecto.model.entities.CategoriaProductoEntity;
import dgtic.proyecto.model.entities.ProductoEntity;
import dgtic.proyecto.model.entities.RolEntity;
import dgtic.proyecto.model.entities.UsuarioEntity;
import dgtic.proyecto.service.rol.RolService;
import dgtic.proyecto.service.usuario.UsuarioService;
import dgtic.proyecto.util.RenderPagina;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping(value = "usuario")
public class UsuarioController {

    @Autowired
    UsuarioService usuarioService;

    @Autowired
    RolService rolService;


    @GetMapping("alta-usuario")
    public String altaEspecieRender(Model model) {
        UsuarioEntity usuarioEntity = new UsuarioEntity();
        List<RolEntity> selectRol = rolService.buscarTipo();
        model.addAttribute("contenido", "Alta Usuario");
        model.addAttribute("usuario", usuarioEntity);
        model.addAttribute("selectRol", selectRol);

        return "usuario/alta-usuario";
    }

    @PostMapping("salvar-usuario")
    public String salvarObjectThymeleaf(@Valid @ModelAttribute("usuario") UsuarioEntity usuario, BindingResult result,
                                        Model model, RedirectAttributes flash,
                                        SessionStatus sesion) {
        List<RolEntity> selectRol= rolService.buscarTipo();

        model.addAttribute("selectRol", selectRol);
        if (result.hasErrors()) {
            model.addAttribute("contenido", "Error en la entra de datos");
            return "usuario/alta-usuario";
        }else{

            usuarioService.guardar(usuario);
            sesion.setComplete();
            flash.addAttribute("success", "usuario se almaceno con éxito");

            return "usuario/alta-usuario";
        }
    }

    @GetMapping("lista-usuario")
    public String listaUsuario(@RequestParam(name = "page",
            defaultValue = "0") int page,
                                Model model) {
        Pageable pagReq = PageRequest.of(page, 2);
        Page<UsuarioEntity> usuarioEntities = usuarioService.buscarUsuario(pagReq);
        RenderPagina<UsuarioEntity> render = new RenderPagina<>("lista-usuario", usuarioEntities);
        model.addAttribute("usuario", usuarioEntities);
        model.addAttribute("page", render);
        model.addAttribute("contenido", "Lista de usuario");
        return "usuario/lista-usuario";
    }

    @GetMapping("modificar-usuario/{id}")
    public String saltoModificar(@PathVariable("id") Integer id, Model model) {
        List<RolEntity> tipo = rolService.buscarTipo();
        UsuarioEntity usuarioEntity = usuarioService.buscarUsuarioId(id);
        model.addAttribute("selectRol", tipo);
        model.addAttribute("usuario", usuarioEntity);
        model.addAttribute("contenido", "Modificar Usuario");
        return "usuario/alta-usuario";
    }

    ///////////ELIMINAR
    @GetMapping("eliminar-usuario/{id}")
    public String saltoEliminar(@PathVariable("id") Integer id, Model model,
                                RedirectAttributes flash) {
        usuarioService.borrar(id);
        flash.addFlashAttribute("success", "Se borro el usuario");
        return "redirect:/usuario/lista-usuario";
    }
}
