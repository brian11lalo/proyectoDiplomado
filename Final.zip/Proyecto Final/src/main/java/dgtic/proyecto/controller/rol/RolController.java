package dgtic.proyecto.controller.rol;

import dgtic.proyecto.model.entities.CategoriaProductoEntity;
import dgtic.proyecto.model.entities.RolEntity;
import dgtic.proyecto.repository.RolRepository;
import dgtic.proyecto.service.rol.RolService;
import dgtic.proyecto.util.RenderPagina;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping(value = "rol")
public class RolController {

    @Autowired
    RolService rolService;


    @GetMapping("alta-rol")
    public String saltoAltaTipo(Model model){
        RolEntity rolEntity = new RolEntity();
        model.addAttribute("contenido","Alta de rol");
        model.addAttribute("rol",rolEntity);
        return "rol/alta-rol";//ruta del recurso
    }
    @RequestMapping(value = "salvar-rol",method = RequestMethod.POST)
    public String salvarConParam(@RequestParam("nombre") String nombre, @RequestParam("tipoRol") String tipoRol,
                                 @RequestParam("direccion") String direccion,@RequestParam("estado") int estado,
                                 @RequestParam(value = "idRol",required = false) Integer id,
                                 RedirectAttributes flash){
        RolEntity rolEntity = new RolEntity();
        rolEntity.setNombre(nombre);
        rolEntity.setTipoRol(tipoRol);
        rolEntity.setDireccion(direccion);
        rolEntity.setEstado(estado);
        if(id!=null){
            rolEntity.setIdRol(id);
            flash.addFlashAttribute("success","rol se modifico con éxito");
        }else{
            flash.addFlashAttribute("success","rol se guardo con éxito");
        }
        //flash.addFlashAttribute("tipo",tipo);
        rolService.guardar(rolEntity);
        return "redirect:/rol/lista-rol";
    }

    @GetMapping("lista-rol")
    public String listaTipo(@RequestParam(name="page",defaultValue = "0")int page,
                            Model model){
        Pageable pagReq= PageRequest.of(page,2);
        Page<RolEntity> categoriaProductoEntities=rolService.buscarTipo(pagReq);
        RenderPagina<RolEntity> render=new RenderPagina<RolEntity>("lista-rol",categoriaProductoEntities);
        model.addAttribute("rol",categoriaProductoEntities);
        model.addAttribute("page",render);
        model.addAttribute("contenido","Lista de Rol del Usuario ");
        return "rol/lista-rol";
    }
    @GetMapping("modificar-rol/{id}")
    public String saltoModificar(@PathVariable("id") Integer id, Model model){
        RolEntity categoriaProductoEntity = rolService.buscarRolId(id);
        model.addAttribute("rol",categoriaProductoEntity);
        model.addAttribute("contenido","Modificar Tipo de Rol");
        return "rol/alta-rol";
    }
    @GetMapping("eliminar-rol/{id}")
    public String eliminar(@PathVariable("id") Integer id,RedirectAttributes flash){
        rolService.borrar(id);
        flash.addFlashAttribute("success","Se borro  rol con éxito Tipo");
        return "redirect:/rol/lista-rol";
    }
}
