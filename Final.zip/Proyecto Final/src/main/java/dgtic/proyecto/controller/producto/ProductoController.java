package dgtic.proyecto.controller.producto;

import dgtic.proyecto.model.entities.CategoriaProductoEntity;
import dgtic.proyecto.model.entities.ProductoEntity;
import dgtic.proyecto.service.categoria.CategoriaProductoService;
import dgtic.proyecto.service.producto.ProductoService;
import dgtic.proyecto.util.RenderPagina;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping(value = "producto")
public class ProductoController {
    @Autowired
    ProductoService productoService;
    @Autowired
    CategoriaProductoService categoriaProductoService;




    @GetMapping("/shop")
    public String mostrarListaProductos(Model model) {
        // Obtener la lista de productos desde el servicio
       // List<ProductoEntity> listaProductos = productoService.buscarProducto();
        List<ProductoEntity> listaProductos = productoService.obtenerProductosConDescuento();
        List<CategoriaProductoEntity> categorias = categoriaProductoService.findCategoria();

        List<ProductoEntity> productosMasVendidos = productoService.obtenerProductosMasVendidos();
        for (ProductoEntity producto : listaProductos) {
            double precioFinal = producto.getPrecio() * (1 - (producto.getDescuento() / 100.0));
            double precioFormateado = Math.round(precioFinal * 100.0) / 100.0;
            producto.setPrecio(precioFormateado);
        }
        model.addAttribute("productos", listaProductos);
        model.addAttribute("categorias", categorias);
        model.addAttribute("productosMasVendidos", productosMasVendidos);
        model.addAttribute("mas", "Productos Más Vendidos");
        model.addAttribute("descuentos","Descuentos");

        // Retornar el nombre de la vista HTML que mostrará la lista de productos
        return "producto/lista-productos";
    }


    @GetMapping("alta-producto")
    public String altaEspecieRender(Model model) {
        ProductoEntity productoEntity = new ProductoEntity();
        List<CategoriaProductoEntity> selectCategoria = categoriaProductoService.buscarTipo();
        model.addAttribute("contenido", "Alta Producto");
        model.addAttribute("producto", productoEntity);
        model.addAttribute("selectCategoria", selectCategoria);

        return "producto/alta-producto";
    }

    @PostMapping("salvar-producto")
    public String salvarObjectThymeleaf(@Valid @ModelAttribute("producto") ProductoEntity producto, BindingResult result,
                                        Model model, RedirectAttributes flash,
                                        SessionStatus sesion) {
        List<CategoriaProductoEntity> selectLote = categoriaProductoService.buscarTipo();

        model.addAttribute("selectCategoria", selectLote);
        if (result.hasErrors()) {
            model.addAttribute("contenido", "Error en la entra de datos");
            return "producto/alta-producto";
        }else{
        productoService.guardar(producto);
        sesion.setComplete();
        flash.addAttribute("success", "producto se almaceno con éxito");

        return "producto/alta-producto";
        }
    }

    @GetMapping("lista-producto")
    public String listaProducto(@RequestParam(name = "page",
            defaultValue = "0") int page,
                               Model model) {
        Pageable pagReq = PageRequest.of(page, 2);
        Page<ProductoEntity> productoEntities = productoService.buscarProducto(pagReq);
        RenderPagina<ProductoEntity> render = new RenderPagina<>("lista-producto", productoEntities);
        model.addAttribute("producto", productoEntities);
        model.addAttribute("page", render);
        model.addAttribute("contenido", "Lista de Producto");
        return "producto/lista-producto";
    }

    @GetMapping("modificar-producto/{id}")
    public String saltoModificar(@PathVariable("id") Integer id, Model model) {
        List<CategoriaProductoEntity> tipo = categoriaProductoService.buscarTipo();
        ProductoEntity productoEntity = productoService.buscarProductoId(id);
        model.addAttribute("selectCategoria", tipo);
        model.addAttribute("producto", productoEntity);
        model.addAttribute("contenido", "Modificar Producto");
        return "producto/alta-producto";
    }

    ///////////ELIMINAR
    @GetMapping("eliminar-producto/{id}")
    public String saltoEliminar(@PathVariable("id") Integer id, Model model,
                                RedirectAttributes flash) {
        productoService.borrar(id);
        flash.addFlashAttribute("success", "Se borro la Especie de Peces");
        return "redirect:/producto/lista-producto";
    }


}
