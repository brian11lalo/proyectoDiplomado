package dgtic.proyecto.controller;


import dgtic.proyecto.model.entities.ProductoEntity;
import dgtic.proyecto.service.AdminService;
import dgtic.proyecto.service.HomeService;
import dgtic.proyecto.service.UserService;
import dgtic.proyecto.service.categoria.CategoriaProductoService;
import dgtic.proyecto.service.producto.ProductoService;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class HomeController {
	private final HomeService homeService;
	private final UserService userService;
	private final AdminService adminService;
	@Autowired
	ProductoService productoService;
	@Autowired
	CategoriaProductoService categoriaProductoService;
	@Autowired
	private JavaMailSender javaMailSender;


	// Controller Injection
	public HomeController(HomeService homeService, UserService userService, AdminService adminService) {
		this.homeService = homeService;
		this.userService = userService;
		this.adminService = adminService;
	}

	@GetMapping(value = {"/", ""})
	public String home(Model model) {
		// Obtener la lista de productos desde el servicio
		// List<ProductoEntity> listaProductos = productoService.buscarProducto();
		List<ProductoEntity> listaProductos = productoService.obtenerProductosConDescuento();
		List<ProductoEntity> productosMasVendidos = productoService.obtenerProductosMasVendidos();
		for (ProductoEntity producto : listaProductos) {
			double precioFinal = producto.getPrecio() * (1 - (producto.getDescuento() / 100.0));
			double precioFormateado = Math.round(precioFinal * 100.0) / 100.0;
			producto.setPrecio(precioFormateado);
		}
		model.addAttribute("productos", listaProductos);
		model.addAttribute("productosMasVendidos", productosMasVendidos);
		model.addAttribute("mas", "Productos Más Vendidos");
		model.addAttribute("descuentos","Descuentos");

		// Retornar el nombre de la vista HTML que mostrará la lista de productos
		model.addAttribute("text", homeService.getText());
		return "index";
	}

	@GetMapping("/contacto")
	public String contacto(){
		return "contacto";
	}
	@GetMapping("/contactoEnviado")
	public String contactoEnviado(){
		return "contactoEnviado";
	}
	@PostMapping("/enviarCorreo")
	public String enviarCorreo(@RequestParam("nombre") String nombre,
							   @RequestParam("email") String email,
							   @RequestParam("mensaje") String mensaje) {

		MimeMessage mimeMessage = javaMailSender.createMimeMessage();
		MimeMessageHelper helper;
		try {
			helper = new MimeMessageHelper(mimeMessage, true);
			helper.setFrom("brianguerrero47@aragon.unam.mx");
			helper.setTo("brian.guerrero1@hotmail.com");
			helper.setSubject("Mensaje de contacto de " + nombre);
			helper.setText("Email: " + email + "<br>Mensaje: " + mensaje, true);

			javaMailSender.send(mimeMessage);

			// Envío de correo electrónico exitoso, puedes redirigir a una página de confirmación
			return "redirect:/contactoEnviado";

		} catch (MessagingException e) {
			// Manejar errores aquí
			e.printStackTrace();
			// Redirigir a una página de error si ocurre un problema
			return "redirect:/index";
		}
	}

	@GetMapping("/productos")
	public String productos(Model model){
		List<ProductoEntity> productos = productoService.obtenerTodosLosProductos();
		model.addAttribute("productos",productos);
		return "productos";
	}

	@GetMapping("/ofertas")
	public String ofertas(Model model){
		List<ProductoEntity> listaProductos = productoService.obtenerProductosConDescuento();
		model.addAttribute("productos",listaProductos);
		return "ofertas";
	}


	@GetMapping("/administrar")
	public String admin() {

		return "plantillas/plantilla";
	}

	@GetMapping("/index")
	public String index() {
		return "redirect:/";
	}

	@GetMapping("/user")
	public String user(Model model) {
		// Obtener la lista de productos desde el servicio
		// List<ProductoEntity> listaProductos = productoService.buscarProducto();
		List<ProductoEntity> listaProductos = productoService.obtenerProductosConDescuento();
		List<ProductoEntity> productosMasVendidos = productoService.obtenerProductosMasVendidos();
		for (ProductoEntity producto : listaProductos) {
			double precioFinal = producto.getPrecio() * (1 - (producto.getDescuento() / 100.0));
			double precioFormateado = Math.round(precioFinal * 100.0) / 100.0;
			producto.setPrecio(precioFormateado);
		}
		model.addAttribute("productos", listaProductos);
		model.addAttribute("productosMasVendidos", productosMasVendidos);
		model.addAttribute("mas", "Productos Más Vendidos");
		model.addAttribute("descuentos","Descuentos");

		// Retornar el nombre de la vista HTML que mostrará la lista de productos
		model.addAttribute("text", homeService.getText());
		return "user";
	}

	@GetMapping("/admin")
	public String admin(Model model) {
		// Obtener la lista de productos desde el servicio
		// List<ProductoEntity> listaProductos = productoService.buscarProducto();
		List<ProductoEntity> listaProductos = productoService.obtenerProductosConDescuento();
		List<ProductoEntity> productosMasVendidos = productoService.obtenerProductosMasVendidos();
		for (ProductoEntity producto : listaProductos) {
			double precioFinal = producto.getPrecio() * (1 - (producto.getDescuento() / 100.0));
			double precioFormateado = Math.round(precioFinal * 100.0) / 100.0;
			producto.setPrecio(precioFormateado);
		}
		model.addAttribute("productos", listaProductos);
		model.addAttribute("productosMasVendidos", productosMasVendidos);
		model.addAttribute("mas", "Productos Más Vendidos");
		model.addAttribute("descuentos","Descuentos");

		// Retornar el nombre de la vista HTML que mostrará la lista de productos
		model.addAttribute("text", homeService.getText());
		return "admin";
	}

	@GetMapping("/login")
	public String login() {
		return "login";
	}

	@PostMapping("/login_success_handler")
	public String loginSuccessHandler() {
		System.out.println("Logging user login success...");
		return "index";
	}

	@PostMapping("/login_failure_handler")
	public String loginFailureHandler() {
		System.out.println("Login failure handler....");
		return "login";
	}
	@GetMapping("/registro")
	public String registro(){
		return "registro";
	}
}

