package dgtic.proyecto.model.entities;


import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.List;
import java.util.Objects;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "producto")
public class ProductoEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idproducto")
    private Integer idProducto;

    @Column(name = "nombre", unique = true)
    private String nombre;

    @Column(name = "descuento")
    private Integer descuento;

    @Column(name = "imagen")
    private String imagen;

    @Column(name = "stock")
    private int stock;

    @Column(name = "precio")
    private double precio;

    @Column(name = "descripcion")
    private String descripcion;

    @Column(name = "porcentaje_iva")
    private double porcentajeIva;

    @Column(name = "existencia")
    private int existencia;




    @ManyToOne
    @JoinColumn(name = "idcategoria")
    private CategoriaProductoEntity categoriaProductoEntity;


    @OneToMany(
            mappedBy = "productoEntity"
    )
    private List<DetalleVentaEntity> detalleVentaEntities;


    public Integer getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(Integer idProducto) {
        this.idProducto = idProducto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Integer getDescuento() {
        return descuento;
    }

    public void setDescuento(Integer descuento) {
        this.descuento = descuento;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public double getPrecio() {
        return precio;
    }

    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getPorcentajeIva() {
        return porcentajeIva;
    }

    public void setPorcentajeIva(double porcentajeIva) {
        this.porcentajeIva = porcentajeIva;
    }

    public int getExistencia() {
        return existencia;
    }

    public void setExistencia(int existencia) {
        this.existencia = existencia;
    }

    public CategoriaProductoEntity getCategoriaProductoEntity() {
        return categoriaProductoEntity;
    }

    public void setCategoriaProductoEntity(CategoriaProductoEntity categoriaProductoEntity) {
        this.categoriaProductoEntity = categoriaProductoEntity;
    }

    @Override
    public String toString() {
        return "ProductoEntity{" +
                "idProducto=" + idProducto +
                ", nombre='" + nombre + '\'' +
                ", descuento=" + descuento +
                ", imagen='" + imagen + '\'' +
                ", stock=" + stock +
                ", precio=" + precio +
                ", descripcion='" + descripcion + '\'' +
                ", porcentajeIva=" + porcentajeIva +
                ", existencia=" + existencia +
                ", categoriaProductoEntity=" + categoriaProductoEntity +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ProductoEntity that = (ProductoEntity) o;
        return Objects.equals(idProducto, that.idProducto);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idProducto);
    }
}

