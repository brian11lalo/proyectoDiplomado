package dgtic.proyecto.repository;


import dgtic.proyecto.model.entities.UsuarioEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

public interface UsuarioRepository extends JpaRepository<UsuarioEntity,Integer> {
}
