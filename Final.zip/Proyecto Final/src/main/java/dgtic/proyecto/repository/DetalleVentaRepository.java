package dgtic.proyecto.repository;


import dgtic.proyecto.model.entities.DetalleVentaEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;


public interface DetalleVentaRepository extends JpaRepository<DetalleVentaEntity,Integer> {
}
