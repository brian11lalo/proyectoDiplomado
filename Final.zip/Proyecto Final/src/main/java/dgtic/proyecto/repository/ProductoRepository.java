package dgtic.proyecto.repository;

import dgtic.proyecto.model.entities.ProductoEntity;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;


public interface ProductoRepository extends JpaRepository<ProductoEntity,Integer> {
    @Query("SELECT p FROM ProductoEntity p WHERE p.descuento > 0 ORDER BY p.descuento DESC LIMIT 6")
    List<ProductoEntity> findProductosWithDescuento();

    @Query("SELECT p FROM ProductoEntity p JOIN DetalleVentaEntity dv ON p.idProducto = dv.productoEntity.idProducto " +
            "GROUP BY p.idProducto ORDER BY SUM(dv.cantidad) DESC LIMIT 6")
    List<ProductoEntity> findProductosMasVendidos();
}
