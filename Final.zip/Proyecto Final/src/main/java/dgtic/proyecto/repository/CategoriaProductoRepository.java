package dgtic.proyecto.repository;

import dgtic.proyecto.model.entities.CategoriaProductoEntity;

import dgtic.proyecto.model.entities.ProductoEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface CategoriaProductoRepository extends JpaRepository<CategoriaProductoEntity,Integer> {
    @Query("SELECT p.descripcion FROM CategoriaProductoEntity p")
    List<CategoriaProductoEntity> findCategoria();

}
