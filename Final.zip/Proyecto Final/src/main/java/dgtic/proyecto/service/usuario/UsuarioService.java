package dgtic.proyecto.service.usuario;

import dgtic.proyecto.model.entities.ProductoEntity;
import dgtic.proyecto.model.entities.UsuarioEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface UsuarioService {
    Page<UsuarioEntity> buscarUsuario(Pageable pageable);
    List<UsuarioEntity> buscarUsuario();
    void guardar(UsuarioEntity tipoEntity);
    void borrar(Integer id);
    UsuarioEntity buscarUsuarioId(Integer id);
}

