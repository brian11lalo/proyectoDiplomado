package dgtic.proyecto.service.categoria;

import dgtic.proyecto.model.entities.CategoriaProductoEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface CategoriaProductoService {
    Page<CategoriaProductoEntity> buscarTipo(Pageable pageable);
    List<CategoriaProductoEntity> buscarTipo();

    List<CategoriaProductoEntity> findCategoria();
    void guardar(CategoriaProductoEntity tipoEntity);
    void borrar(Integer id);
    CategoriaProductoEntity buscarCategoriaProductoEntityId(Integer id);
//    List<CategoriaProductoEntity> buscarTipoPatron(String patron);
}
