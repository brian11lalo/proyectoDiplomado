package dgtic.proyecto.service.usuario;

import dgtic.proyecto.model.entities.ProductoEntity;
import dgtic.proyecto.model.entities.UsuarioEntity;
import dgtic.proyecto.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class UsuarioServiceImpl implements UsuarioService{

    @Autowired
    UsuarioRepository usuarioRepository;

    @Override
    @Transactional(readOnly = true)//no hace modificacion por eso es transasc
    public Page<UsuarioEntity> buscarUsuario(Pageable pageable) {
        return usuarioRepository.findAll(pageable);
    }

    @Override
    @Transactional(readOnly = true)//solo consulta no modifica
    public List<UsuarioEntity> buscarUsuario() {
        return usuarioRepository.findAll();
    }

    @Override
    @Transactional//hace rollback
    public void guardar(UsuarioEntity tipoEntity) {
        usuarioRepository.save(tipoEntity);
    }

    @Override
    @Transactional//hace rollback
    public void borrar(Integer id) {
        usuarioRepository.deleteById(id);
    }

    @Override
    @Transactional(readOnly = true)//solo consulta no modifica
    public UsuarioEntity buscarUsuarioId(Integer id) {
        Optional<UsuarioEntity> op = usuarioRepository.findById(id);//optional da la opcion que pueda ser nulo el resultado
        return op.orElse(null);
    }

}
