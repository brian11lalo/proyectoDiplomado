package dgtic.proyecto.controller.categoriaproducto;


import dgtic.proyecto.model.entities.CategoriaProductoEntity;
import dgtic.proyecto.model.entities.ProductoEntity;
import dgtic.proyecto.service.categoria.CategoriaProductoService;
import dgtic.proyecto.util.RenderPagina;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping(value = "categoria")
public class CategoriaProductoController {

    @Autowired
    CategoriaProductoService categoriaProductoService;

    @GetMapping("alta-categoria")
    public String saltoAltaTipo(Model model){
        CategoriaProductoEntity categoriaProductoEntity = new CategoriaProductoEntity();
        model.addAttribute("contenido","Alta de Categoria Producto");
        model.addAttribute("categoriaproducto",categoriaProductoEntity);
        return "categoria/alta-categoria";//ruta del recurso
    }


    @RequestMapping(value = "salvar-categoria",method = RequestMethod.POST)
    public String salvarConParam(@RequestParam("descripcion") String descripcion,@RequestParam("cantidad") int cantidad,
                                 @RequestParam("estado") int estado,
                                 @RequestParam(value = "idCategoria",required = false) Integer id,
                                 RedirectAttributes flash){
        CategoriaProductoEntity categoriaProductoEntity = new CategoriaProductoEntity();
        categoriaProductoEntity.setDescripcion(descripcion);
        categoriaProductoEntity.setCantidad(cantidad);
        categoriaProductoEntity.setEstado(estado);
        if(id!=null){
            categoriaProductoEntity.setIdCategoria(id);
            flash.addFlashAttribute("success","categoria se modifico con éxito");
        }else{
            flash.addFlashAttribute("success","categoria se guardo con éxito");
        }
        //flash.addFlashAttribute("tipo",tipo);
        categoriaProductoService.guardar(categoriaProductoEntity);
        return "redirect:/categoria/lista-categoria";
    }

    @GetMapping("lista-categoria")
    public String listaTipo(@RequestParam(name="page",defaultValue = "0")int page,
                            Model model){
        Pageable pagReq= PageRequest.of(page,2);
        Page<CategoriaProductoEntity> categoriaProductoEntities=categoriaProductoService.buscarTipo(pagReq);
        RenderPagina<CategoriaProductoEntity> render=new RenderPagina<CategoriaProductoEntity>("lista-categoria",categoriaProductoEntities);
        model.addAttribute("categoriaproducto",categoriaProductoEntities);
        model.addAttribute("page",render);
        model.addAttribute("contenido","Lista de Categoria del Producto ");
        return "categoria/lista-categoria";
    }
    @GetMapping("modificar-categoria/{id}")
    public String saltoModificar(@PathVariable("id") Integer id, Model model){
        CategoriaProductoEntity categoriaProductoEntity = categoriaProductoService.buscarCategoriaProductoEntityId(id);
        model.addAttribute("categoriaproducto",categoriaProductoEntity);
        model.addAttribute("contenido","Modificar Tipo de Peces");
        return "categoria/alta-categoria";
    }
    @GetMapping("eliminar-categoria/{id}")
    public String eliminar(@PathVariable("id") Integer id,RedirectAttributes flash){
        categoriaProductoService.borrar(id);
        flash.addFlashAttribute("success","Se borro con éxito Tipo");
        return "redirect:/categoria/lista-categoria";
    }
}
