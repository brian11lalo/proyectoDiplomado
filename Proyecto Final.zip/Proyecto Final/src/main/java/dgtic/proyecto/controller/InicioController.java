package dgtic.proyecto.controller;

import dgtic.proyecto.model.entities.ProductoEntity;
import dgtic.proyecto.service.producto.ProductoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Controller

public class InicioController {

/*
    @Autowired
    ProductoService productoService;
    @Value("${spring.application.name}")
    String nombreApp;

    @RequestMapping(value = "/",method = RequestMethod.GET)
    String inicioPagina(Model model){
        SimpleDateFormat formateadorFecha = new SimpleDateFormat("dd/MM/yyyy");
        model.addAttribute("fecha",formateadorFecha.format(new Date()));
        model.addAttribute("nombreAplicacion",nombreApp);
        return "inicio";
    }
    @GetMapping("/inicio")
    String inicioDos(Model model){
        model.addAttribute("fecha","No hay fecha");
        model.addAttribute("nombreAplicacion","Se cambio");
        return "index";
    }
    @GetMapping("/index")
    public String index(Model model){
        // Obtener la lista de productos desde el servicio
        List<ProductoEntity> listaProductos = productoService.buscarProducto();

        // Agregar la lista de productos al modelo para enviarla a la vista
        model.addAttribute("productos", listaProductos);

        return "index";
    }*/
}
