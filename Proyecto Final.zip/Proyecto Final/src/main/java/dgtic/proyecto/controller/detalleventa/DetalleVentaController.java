package dgtic.proyecto.controller.detalleventa;

import dgtic.proyecto.model.entities.CategoriaProductoEntity;
import dgtic.proyecto.model.entities.DetalleVentaEntity;
import dgtic.proyecto.model.entities.ProductoEntity;
import dgtic.proyecto.model.entities.UsuarioEntity;
import dgtic.proyecto.repository.DetalleVentaRepository;
import dgtic.proyecto.repository.ProductoRepository;
import dgtic.proyecto.service.detalleventa.DetalleVentaService;
import dgtic.proyecto.service.producto.ProductoService;
import dgtic.proyecto.util.RenderPagina;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping(value = "detalleventa")
public class DetalleVentaController {

    @Autowired
    ProductoService productoService;
    @Autowired
    DetalleVentaService detalleVentaService;


    @GetMapping("alta-detalleventa")
    public String altaEspecieRender(Model model) {
        DetalleVentaEntity detalleVentaEntity = new DetalleVentaEntity();
        List<ProductoEntity> selectProducto = productoService.buscarProducto();
        model.addAttribute("contenido", "Alta Detalle Venta");
        model.addAttribute("detalleventa", detalleVentaEntity);
        model.addAttribute("selectProducto", selectProducto);

        return "detalleventa/alta-detalleventa";
    }

    @PostMapping("salvar-detalleventa")
    public String salvarObjectThymeleaf(@Valid @ModelAttribute("detalleventa") DetalleVentaEntity producto, BindingResult result,
                                        Model model, RedirectAttributes flash,
                                        SessionStatus sesion) {
        List<ProductoEntity> selectLote = productoService.buscarProducto();

        model.addAttribute("selectProducto", selectLote);
        if (result.hasErrors()) {
            model.addAttribute("contenido", "Error en la entra de datos");
            return "detalleventa/alta-detalleventa";
        }else{
            detalleVentaService.guardar(producto);
            sesion.setComplete();
            flash.addAttribute("success", "detalleventav se almaceno con éxito");

            return "detalleventa/alta-detalleventa";
        }
    }

    @GetMapping("lista-detalleventa")
    public String listaProducto(@RequestParam(name = "page",
            defaultValue = "0") int page,
                                Model model) {
        Pageable pagReq = PageRequest.of(page, 2);
        Page<DetalleVentaEntity> detalleVentaEntities = detalleVentaService.buscarDetalle(pagReq);
        RenderPagina<DetalleVentaEntity> render = new RenderPagina<>("lista-detalleventa", detalleVentaEntities);
        model.addAttribute("detalleventa", detalleVentaEntities);
        model.addAttribute("page", render);
        model.addAttribute("contenido", "Lista de detalleventa");
        return "detalleventa/lista-detalleventa";
    }

    @GetMapping("modificar-detalleventa/{id}")
    public String saltoModificar(@PathVariable("id") Integer id, Model model) {
        List<ProductoEntity> tipo = productoService.buscarProducto();
        DetalleVentaEntity detalleVentaEntity = detalleVentaService.buscarDetalleId(id);
        model.addAttribute("selectProducto", tipo);
        model.addAttribute("detalleventa", detalleVentaEntity);
        model.addAttribute("contenido", "Modificar DetalleVenta");
        return "detalleventa/alta-detalleventa";
    }

    ///////////ELIMINAR
    @GetMapping("eliminar-detalleventa/{id}")
    public String saltoEliminar(@PathVariable("id") Integer id, Model model,
                                RedirectAttributes flash) {
        detalleVentaService.borrar(id);
        flash.addFlashAttribute("success", "Se borro la detalleventa ");
        return "redirect:/detalleventa/lista-detalleventa";
    }

}
