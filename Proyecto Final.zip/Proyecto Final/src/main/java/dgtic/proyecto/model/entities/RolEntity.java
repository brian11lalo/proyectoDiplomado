package dgtic.proyecto.model.entities;


import jakarta.persistence.*;

import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "rol")
public class RolEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idrol")
    private Integer idRol;

    @Column(name = "nombre")
    private String nombre;

    @Column(name = "tiporol")
    private String tipoRol;

    @Column(name = "direccion")
    private String direccion;

    @Column(name = "estado")
    private int estado;

    @OneToMany(
            mappedBy = "rolEntity"
    )
    private List<UsuarioEntity> usuarioEntities;

    public Integer getIdRol() {
        return idRol;
    }

    public void setIdRol(Integer idRol) {
        this.idRol = idRol;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipoRol() {
        return tipoRol;
    }

    public void setTipoRol(String tipoRol) {
        this.tipoRol = tipoRol;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public int getEstado() {
        return estado;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }


    @Override
    public String toString() {
        return "RolEntity{" +
                "idRol=" + idRol +
                ", nombre='" + nombre + '\'' +
                ", tipoRol='" + tipoRol + '\'' +
                ", direccion='" + direccion + '\'' +
                ", estado=" + estado +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RolEntity rolEntity = (RolEntity) o;
        return Objects.equals(idRol, rolEntity.idRol);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idRol);
    }
}
