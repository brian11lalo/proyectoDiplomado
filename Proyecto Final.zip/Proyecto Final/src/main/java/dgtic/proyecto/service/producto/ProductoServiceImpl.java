package dgtic.proyecto.service.producto;

import dgtic.proyecto.model.entities.CategoriaProductoEntity;
import dgtic.proyecto.model.entities.ProductoEntity;
import dgtic.proyecto.repository.ProductoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class ProductoServiceImpl implements ProductoService {

    @Autowired
    ProductoRepository productoRepository;

    @Override
    @Transactional(readOnly = true)//no hace modificacion por eso es transasc
    public Page<ProductoEntity> buscarProducto(Pageable pageable) {
        return productoRepository.findAll(pageable);
    }

    @Override
    public List<ProductoEntity> obtenerProductosConDescuento() {
        return productoRepository.findProductosWithDescuento();
    }

    public List<ProductoEntity> obtenerProductosMasVendidos() {
        return productoRepository.findProductosMasVendidos();
    }

    @Override
    @Transactional(readOnly = true)//solo consulta no modifica
    public List<ProductoEntity> buscarProducto() {
        return productoRepository.findAll();
    }

    @Override
    @Transactional//hace rollback
    public void guardar(ProductoEntity tipoEntity) {
        productoRepository.save(tipoEntity);
    }

    @Override
    @Transactional//hace rollback
    public void borrar(Integer id) {
        productoRepository.deleteById(id);
    }

//    @Override
//    @Transactional(readOnly = true)
//    public List<ProductoEntity> obtenerProductosConDescuento() {
//        return productoRepository.buscarProductosConDescuento();
//    }
    @Override
    @Transactional(readOnly = true)//solo consulta no modifica
    public ProductoEntity buscarProductoId(Integer id) {
        Optional<ProductoEntity> op = productoRepository.findById(id);//optional da la opcion que pueda ser nulo el resultado
        return op.orElse(null);
    }

}
