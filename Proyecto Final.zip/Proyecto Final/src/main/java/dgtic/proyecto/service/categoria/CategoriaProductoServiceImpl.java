package dgtic.proyecto.service.categoria;

import dgtic.proyecto.model.entities.CategoriaProductoEntity;
import dgtic.proyecto.repository.CategoriaProductoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class CategoriaProductoServiceImpl implements CategoriaProductoService{

    @Autowired
    CategoriaProductoRepository categoriaProductoRepository;

    @Override
    @Transactional(readOnly = true)//no hace modificacion por eso es transasc
    public Page<CategoriaProductoEntity> buscarTipo(Pageable pageable) {
        return categoriaProductoRepository.findAll(pageable);
    }

    @Override
    @Transactional(readOnly = true)//solo consulta no modifica
    public List<CategoriaProductoEntity> buscarTipo() {
        return categoriaProductoRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)//solo consulta no modifica
    public List<CategoriaProductoEntity> findCategoria() {
        return categoriaProductoRepository.findCategoria();
    }




    @Override
    @Transactional//hace rollback
    public void guardar(CategoriaProductoEntity tipoEntity) {
        categoriaProductoRepository.save(tipoEntity);
    }

    @Override
    @Transactional//hace rollback
    public void borrar(Integer id) {
        categoriaProductoRepository.deleteById(id);
    }

    @Override
    @Transactional(readOnly = true)//solo consulta no modifica
    public CategoriaProductoEntity buscarCategoriaProductoEntityId(Integer id) {
        Optional<CategoriaProductoEntity> op = categoriaProductoRepository.findById(id);//optional da la opcion que pueda ser nulo el resultado
        return op.orElse(null);
    }

//    @Override
//    @Transactional(readOnly = true)//solo consulta no modifica
//    public List<CategoriaProductoEntity> buscarTipoPatron(String patron) {
//        return categoriaProductoRepository.findByNombre(patron);
//    }
}
