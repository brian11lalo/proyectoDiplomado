package dgtic.proyecto.service;

import org.springframework.stereotype.Service;

@Service
public class UserService {
	public String getText() {
		return "User";
	}
}
