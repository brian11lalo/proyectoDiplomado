package dgtic.proyecto.service.rol;

import dgtic.proyecto.model.entities.CategoriaProductoEntity;
import dgtic.proyecto.model.entities.RolEntity;
import dgtic.proyecto.repository.CategoriaProductoRepository;
import dgtic.proyecto.repository.RolRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class RolServiceImpl implements RolService{

    @Autowired
    RolRepository rolRepository;

    @Override
    @Transactional(readOnly = true)//no hace modificacion por eso es transasc
    public Page<RolEntity> buscarTipo(Pageable pageable) {
        return rolRepository.findAll(pageable);
    }

    @Override
    @Transactional(readOnly = true)//solo consulta no modifica
    public List<RolEntity> buscarTipo() {
        return rolRepository.findAll();
    }

    @Override
    @Transactional//hace rollback
    public void guardar(RolEntity tipoEntity) {
        rolRepository.save(tipoEntity);
    }

    @Override
    @Transactional//hace rollback
    public void borrar(Integer id) {
        rolRepository.deleteById(id);
    }

    @Override
    @Transactional(readOnly = true)//solo consulta no modifica
    public RolEntity buscarRolId(Integer id) {
        Optional<RolEntity> op = rolRepository.findById(id);//optional da la opcion que pueda ser nulo el resultado
        return op.orElse(null);
    }
}
