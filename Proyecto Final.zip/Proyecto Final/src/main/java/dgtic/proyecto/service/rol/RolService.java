package dgtic.proyecto.service.rol;

import dgtic.proyecto.model.entities.CategoriaProductoEntity;
import dgtic.proyecto.model.entities.RolEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface RolService {

    Page<RolEntity> buscarTipo(Pageable pageable);
    List<RolEntity> buscarTipo();
    void guardar(RolEntity tipoEntity);
    void borrar(Integer id);
    RolEntity buscarRolId(Integer id);
}
