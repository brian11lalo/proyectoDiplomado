package dgtic.proyecto.service.detalleventa;

import dgtic.proyecto.model.entities.DetalleVentaEntity;
import dgtic.proyecto.model.entities.ProductoEntity;
import dgtic.proyecto.repository.DetalleVentaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class DetalleVentaSeviceImpl implements DetalleVentaService{


    @Autowired
    DetalleVentaRepository detalleVentaRepository;

    @Override
    @Transactional(readOnly = true)//no hace modificacion por eso es transasc
    public Page<DetalleVentaEntity> buscarDetalle(Pageable pageable) {
        return detalleVentaRepository.findAll(pageable);
    }

    @Override
    @Transactional(readOnly = true)//solo consulta no modifica
    public List<DetalleVentaEntity> buscarDetalle() {
        return detalleVentaRepository.findAll();
    }

    @Override
    @Transactional//hace rollback
    public void guardar(DetalleVentaEntity tipoEntity) {
        detalleVentaRepository.save(tipoEntity);
    }

    @Override
    @Transactional//hace rollback
    public void borrar(Integer id) {
        detalleVentaRepository.deleteById(id);
    }

    @Override
    @Transactional(readOnly = true)//solo consulta no modifica
    public DetalleVentaEntity buscarDetalleId(Integer id) {
        Optional<DetalleVentaEntity> op = detalleVentaRepository.findById(id);//optional da la opcion que pueda ser nulo el resultado
        return op.orElse(null);
    }
}
